package com.example.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="users")
public class Users {
	@Id
	@Column(name="id")
	private long id;
	
	@Column(name = "Firstname")
	private String Firstname;
	
	@Column(name="LastName")
	private String LastName;

	@Column(name="email_address")
	private String email_address;

	public String getEmail_address() {
		return email_address;
	}

	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return Firstname;
	}

	public void setFirstName(String Firstname) {
		this.Firstname = Firstname;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}
	

}
