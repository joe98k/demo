package com.example.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.entities.Users;
import com.example.repository.UserRepository;



@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired UserRepository userRepository;
	
	@GetMapping("/users")
	public List<Users> getAllUsers(){
		return userRepository.findAll();
	}
	
	@GetMapping("/users/{id}")
	  public ResponseEntity<Users> getUsersById(@PathVariable(value = "id") Long userId)
	      throws EntityNotFoundException {
	    Users user = userRepository.findById(userId).orElseThrow(() ->(new EntityNotFoundException("User not found on :: " + userId)));
	    return ResponseEntity.ok().body(user);
	  }

	@PostMapping("/users")
	  public Users createUser(@Validated @RequestBody Users user) {
	    return userRepository.save(user);
	  }
	
	@PutMapping("/users/{id}")
	public ResponseEntity<Users> updateUser(@PathVariable(value="id") Long userId, @Validated @RequestBody Users userDetails)
			throws EntityNotFoundException {

	    Users users = userRepository.findById(userId).orElseThrow(() -> (new EntityNotFoundException("User not found on :: " + userId)));

	    users.setEmail_address(userDetails.getEmail_address());
	    users.setLastName(userDetails.getLastName());
	    users.setFirstName(userDetails.getFirstName());
	    final Users updatedUser = userRepository.save(users);
	    return ResponseEntity.ok(updatedUser);
	  }

	 @DeleteMapping("/user/{id}")
	  public Map<String, Boolean> deleteUser(@PathVariable(value = "id") Long userId) throws Exception {
	    Users user =userRepository.findById(userId).orElseThrow(() -> (new EntityNotFoundException("User not found on :: " + userId)));

	    userRepository.delete(user);
	    Map<String, Boolean> response = new HashMap<>();
	    response.put("deleted", Boolean.TRUE);
	    return response;
	  }
	}
	
	
	
	
	
	
	


